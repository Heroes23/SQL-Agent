from pydantic import BaseModel, Field

# User Request class
class UserRequest(BaseModel):

    # Attributes
    age: int
    metastasis: int
    breast_quadrant_lower_inner: int
    breast_quadrant_lower_outer: int
    breast_quadrant_upper_outer: int
    breast_quadrant_upper_inner: int
    breast_quadrant_upper_inner_v2: int

# Metrics Response
class MetricResponse(BaseModel):
    # Attributes
    accuracy_score: float = Field(default=81.82, description="Training accuracy")
    f1_score: float = Field(default=80.00, description="Training F1 Score")

# Prediction Response
class PredictionResponse(BaseModel):
    # Attributes
    label: int
    label_description: str = Field(description="Describes whether the tumor is benign or malignant")
    probability_score: float
    probability_thresh: float = Field(default=0.5)
    