from requests import get

# URL
url = "http://127.0.0.1:8002/data"

# Make a request
response = get(url=url)

# JSON representation of the response
result = response.json()

print(result)