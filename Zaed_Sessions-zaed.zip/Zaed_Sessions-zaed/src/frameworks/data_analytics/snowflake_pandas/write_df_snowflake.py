import pandas as pd

# custom modules
from engine import engine

try:
    # Connection
    cursor = engine.connect()

    print("Connection to Snowflake is successful.")

except Exception as e:
    print(f"Error occurred: {e}")

# Get the DataFrame
url = "https://ashfaq-nsclc-dataset.s3.us-east-1.amazonaws.com/ali_datasets/breast-cancer-dataset.csv"

df = pd.read_csv(url)

print("DataFrame loaded successfully.")

try:
    # .to_sql()
    df.to_sql(name='breast_cancer', con=cursor, index=False, if_exists='replace')

    print("DataFrame loaded as a table successfully on Snowflake.")

except Exception as e:
    print(f"Error occurred: {e}")

finally:
    # Close the connection
    cursor.close()