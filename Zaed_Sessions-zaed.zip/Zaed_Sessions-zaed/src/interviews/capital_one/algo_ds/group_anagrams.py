# def group_anagrams(words: list[str]) -> dict[str, list[str]]:
#     """
#     Given a list of strings, you want to find all the strings that belong to the same anagram group and return
#     the dictionary of each anagram group and the value being the list of strings that belong to that group.
#     """

#     """
#     1. Create an empty dictionary 
#     2. Create a key 
#     3. Add values to that key 
#     4. Printing it 
#     """
#     anagram = {} 
#     for word in words: 
#         key = "".join(count(word))
#         if key in anagram: 
#             anagram[key].append(word)
#         else: 
#             anagram[key] = [word]
#     return anagram

# words = ['ate', 'eat', 'tea', 'teat', 'ttea']

# result = group_anagrams(words=words)

# print(result)


# Helper Function
def count_char_freq(word: str) -> tuple:
    freqs = [0] * 26

    # Iterate through the characters
    for c in word:
        c_idx = ord(c) - ord('a')

        # Update the frequencies
        freqs[c_idx] += 1
    
    # Convert the list into a tuple
    return tuple(freqs)

def group_anagrams(words: list[str]) -> dict[tuple, list[str]]:

    # Anagrams
    anagrams = {}

    # Iterate through each word
    for word in words:

        # Frequencies associated with the word
        word_char_freq = count_char_freq(word=word)

        # Is that frequency already in anagrams?
        if word_char_freq in anagrams:
            # Append the word to the group
            anagrams[word_char_freq].append(word)
        
        else:
            # Create the key, value pair
            anagrams[word_char_freq] = [word]
    
    return anagrams

words = ['ate', 'eat', 'tea', 'teat', 'ttea']

result = group_anagrams(words=words)

print(result)


