from lightgbm import LGBMClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score
from joblib import dump
from os import getcwd

# Custom modules
from feature_selection import result_df

# Initializing the model
model = LGBMClassifier()

# Split your result_df into training and testing set
X = result_df.drop('target').to_numpy()
y = result_df['target'].to_numpy()

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.05, stratify=y)

# Fit the model
model = model.fit(X=X_train, y=y_train)

# Predictions
y_pred = model.predict(X=X_test)

# Evaluation

## Accuracy Score
acc_score = accuracy_score(y_true=y_test, y_pred=y_pred)

## F1 Score
f1 = f1_score(y_true=y_test, y_pred=y_pred)

print(f"Metrics: \n Accuracy: {round(acc_score * 100, 2)}% \n F1 Score: {round(f1 * 100, 2)}%")

# Save the Model
model_path = getcwd() + "/data/models/lgbm_breast_cancer_classifier.pkl"

dump(model, model_path)