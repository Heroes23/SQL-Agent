from typing import Optional
from pydantic import BaseModel, Field

# EmailRegistration
class EmailRegistration(BaseModel):
    """
    ### Pydantic Model: EmailRegistration

    #### Attributes
    - user_id (integer)
    - user_name (string)
    - user_email (string)
    """

    # Attributes
    user_id: int = Field(default=1, description="This is the internal ID of the user.")
    user_name: str = Field(description="This is the internal username on the platform for the registered user.")
    user_email: str = Field(description="This is the email address that the user is supplying for registration.")

# EmailRetrieval
class EmailRetrieval(BaseModel):
    """
    ### Pydantic Model: EmailRetrieval

    #### Attributes
    - user_id (integer)
    - user_name (Optional string)
    """
    # Attributes
    user_id: int = Field(default=1, description="This is the internal ID of the user.")
    user_name: Optional[str] = Field(description="This is the internal username on the platform for the registered user.")