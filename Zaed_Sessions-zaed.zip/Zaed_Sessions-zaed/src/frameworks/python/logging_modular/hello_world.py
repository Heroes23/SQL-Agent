from loguru import logger
from sys import stdout
from os import getcwd
from typing import Union

# Log Path
log_path = getcwd() + "/data/logs/modular_python_loguru.txt"

# Adding to the console
logger.add(stdout, level="INFO")

# Add File Handler to the logger
logger.add(sink=log_path, level="INFO")

# Function for each operation
def ingest_file(file_path: str) -> str:
    
    result = ''
    
    try:
        with open(file_path) as f:
            # Read the file
            result = f.read()
        
        logger.info(f"Successfully able to read the file: {file_path}")
        logger.info(f"File Contents of {file_path}: {result}")
        logger.info(f"Bytes recorded of {file_path}: {len(result)}")
    
    except FileNotFoundError as e:
        logger.error(f"File path: {file_path} does not exist.")
    
    return result

# Greeting function
def greeting(message: str) -> Union[str, None]:
    logger.info("Starting a greeting.")

    greeting = None

    try:
        greeting = f'Hello. {message.capitalize()}.'
        logger.info(f"Greeting initiated: {greeting}")
    
    except TypeError as e:
        logger.error(f"The type of message: {message} , is not a string. Please review. \n Exception: {e}")

    return greeting

class DBConnection:
    def __init__(self, con: str):
        self.con = con
    
    def connect(self) -> str:
        
        result = ''
        
        if 'postgresql' in self.con:
            result = "Connected to: ", self.con
        
        return result
    
# Load to database
def load_to_database(db_connection: str) -> dict:
    result = {}

    try:
        db = DBConnection(con=db_connection)

        logger.info("Attempting to connect to PostgreSQL")

        # Establish the connection
        connection = db.connect()

        if connection != '':
            logger.info("Connection to database was successful.")

            result['connection'] = connection

    
    except ValueError as e:
        logger.error(f"Failed to connect to the database.")
        logger.error(f"Exception: {e}")

        result['connection'] = ''
    
    return result


# Mimicking Airflow
def workflow(file_path: str, db_connection: str, message: str):

    # Go through the steps
    ingest_file(file_path=file_path)

    greeting(message=message)

    load_to_database(db_connection=db_connection)

workflow()