"""

Friend Travel Problem

Description:

- You have a scenario where friends are basically traveling to each other.
- Group the friends based on nearest distances from each other.

"""

friends = [
    {
        'name': 'Sally',
        'x': 10,
        'y': 15
    },

     {
        'name': 'Bill',
        'x': 15,
        'y': 25
    },

     {
        'name': 'Charlie',
        'x': 30,
        'y': 35
    },

     {
        'name': 'Jill',
        'x': 5,
        'y': 10
    },
]

# Helper Functions
def euclidean_distance(x_one: int, y_one: int, x_two: int, y_two: int) -> float:
        return ((x_one - x_two)**2 + (y_one - y_two)**2)**(1/2)

# Transform the dictionaries into a class
class Friend:
    # Constructor
    def __init__(self, name: str, x: int, y: int):
        self.name = name
        self.x = x
        self.y = y
    
    # Calculate Distance
    def calculate_distance(self, other_friend: Friend) -> float:
        return euclidean_distance(x_one=self.x, y_one=self.y, x_two=other_friend.x, y_two=other_friend.y)
   

def group_friends_distance(friends: list[dict], threshold: float = 5.5) -> dict[str, list[Friend]]:
     
    # Results
    results = {}

    # Memoization / Caching
    seen_distances: dict[tuple, float] = {}

    # Iterate through each of the friends
    friends = [Friend(**friend) for friend in friends]

    # Loop through it
    for i in range(len(friends)):
        for j in range(1, len(friends) + 1):
            # First friend
            first_friend: Friend = friends[i]
            
            # Second friend
            second_friend: Friend = friends[j]

            first_friend_name, second_friend_name = sorted([first_friend.name, second_friend.name])

            distance = 0

            if ((first_friend_name, second_friend_name) in seen_distances):
                 distance = seen_distances[(first_friend_name, second_friend_name)]
            
            else:

                # Calculate the distance
                distance = first_friend.calculate_distance(second_friend)

                # Add to the cache
                seen_distances[(first_friend_name, second_friend_name)] = distance
            
            group_num = 0

            if distance < threshold:
                # Add a group
                if group_num in results:
                    # Appending to the group
                    # TODO: Add a function to check which friend is not currently in the group
                    if first_friend in results[group_num]:
                        results[group_num].append(second_friend)
                    elif second_friend in results[group_num]:
                        results[group_num].append(first_friend)

                      
                
                elif group_num not in results:
                 # TODO: 
                 results[group_num] = [first_friend, second_friend]
            
            else:
                group_num += 1
                 

            






