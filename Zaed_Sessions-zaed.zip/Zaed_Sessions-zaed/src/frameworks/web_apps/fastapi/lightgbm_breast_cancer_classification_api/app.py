import numpy as np
from fastapi import FastAPI
from uvicorn import run
from os import getcwd
from joblib import load
from typing import Dict, Union
from lightgbm import LGBMClassifier

# Custom modules
from utils.validation_models import MetricResponse, PredictionResponse, UserRequest

# App object
app = FastAPI()

"""
Load LightGBM Model
"""

model_path = getcwd() + "/data/models/lgbm_breast_cancer_classifier.pkl"

model: LGBMClassifier = load(filename=model_path)

"""
Routes
"""

# 1. make_prediction
@app.post(path='/predict', response_model=PredictionResponse)
def make_prediction(user_request: UserRequest) -> PredictionResponse:
    # Deserialize the Pydantic object into a dictionary
    user_input = list(user_request.model_dump().values())

    # Convert the list of the values into a numpy array
    user_array = np.array(user_input).reshape(1, -1)

    # Make the predictions
    y_pred: int = model.predict(X=user_array)[0]

    y_proba: float = max(model.predict_proba(X=user_array)[0])

    y_label_map = {0: 'Benign', 1: 'Malignant'}

    y_label = y_label_map[y_pred]

    # Response
    response = PredictionResponse(label=y_pred, label_description=y_label, probability_score=y_proba)

    return response

# 2. get_metrics
@app.get(path='/metrics', response_model=MetricResponse)
def get_metrics() -> MetricResponse:
    return MetricResponse()

# Run the server
run(app=app, host='0.0.0.0', port=8003)

