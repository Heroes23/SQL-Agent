from engine import engine

# Connection with SQLAlchemy
cursor = engine.connect()

# SQL Queries
query = """

select 'high'; 

"""

# Execute the SQL string as a valid query on Snowflake
result = cursor.exec_driver_sql(statement=query)
print(result.fetchall())

# Commit the change
cursor.commit()


# Close the connection
cursor.close()