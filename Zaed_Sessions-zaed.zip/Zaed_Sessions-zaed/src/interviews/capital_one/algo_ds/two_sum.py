"""
You want to find indices of two numbers that add up to a given target.

Ex: 
list = [7,2,1,9]
7 = [0]
2 = [1]
9 = 2 + 7 
target = 9 
value = 7 
partner = 2 
two numbers will be 2 and 7. 
"""

def two_sum(nums: list[int], target: int) -> tuple:
    # Create a empty dictionary: 
    seen = {}
    
    result = ()

    # Key in the dictionary referring to : partner
    # Value in the dictionary reffering to : (index, value)

    for index, num in enumerate(nums): 
        partner = target - num
        if num in seen: 
            result = index, seen[num]  # return [seen[partner, index]]
        else:
            # TODO: Update the seen dictionary 
            seen[partner] = index 

    return result

# Testing
nums = [7,2,1,9]
target = 9

result = two_sum(nums=nums, target=target)

print(result)