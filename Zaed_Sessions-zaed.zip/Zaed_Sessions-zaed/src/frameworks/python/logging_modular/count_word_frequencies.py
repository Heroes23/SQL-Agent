from collections import Counter
from logger import logger


# Function - count word frequencies
def count_frequencies(word_string: str) -> dict:

    words = {}

    # Is the length of your word string at least 1
    if len(word_string) >= 1:
        logger.info("Starting to separate words from the string.")

        # Check if a whitespace exists within the string
        if ' ' in word_string:
            logger.info(f"Words can be separated from the string: {word_string}")

            # Try / Except block
            try:
                # Split the string into a list of words and then count frequencies
                words = dict(Counter(word_string.split(' ')))

                logger.info("Word frequencies have been obtained.")
            
            except ValueError as e:
                logger.error(f"Failed to retrieve frequencies for the string: {word_string}")



    return words


word_string = 'apple banana apple pear'

result = count_frequencies(word_string=word_string)

print(result)