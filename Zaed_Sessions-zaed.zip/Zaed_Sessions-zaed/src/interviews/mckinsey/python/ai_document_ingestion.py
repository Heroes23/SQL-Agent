import heapq
from pydantic import BaseModel, Field
from typing import List, Dict, Literal

class LLMOperation(BaseModel):
    llm_model: Literal['gemini', 'gpt', 'claude'] = Field(description="Large language model used for the operation")
    approx_time_complete: float = Field(description="Approximate time to complete the operation in seconds")

class Solution:
    
    """

    Inputs:

    - List of LLM Operations
    - Num of Parallel Processes

    Output
    - Estimated time to complete all operations

    """

    # Init
    def __init__(self, list_operations: List[LLMOperation], num_processes: int):
        self.operations = list_operations
        self.num_processes = num_processes
        self.time_complete = 0

    def build_queues(self) -> List[List[LLMOperation]]:
        # TODO: Iterate through the operations

        # TODO: Check how many processes can you have at one time?

        # TODO: Removing operations from the end of the original operations and push them into the individual queues

        pass

    def calculate_estimated_time(self) -> float:
        
        # TODO: Allocate operations to the processes
        version_history = {}

        ## Build the queues
        queues = self.build_queues()

         ## Took the first few operations and built the partition
        partition = self.build_partition(queues=queues)

        ## Build a partition - list or even a hash map (version history)
        version_history[1] = partition

        # Build a heap - keep track of time taken for the longest running process in the partition
        longest_running_op = self.get_longest_op(partition=partition)
        
        # Update the time taken
        self.time_complete += longest_running_op.approx_time_complete

        # TODO: What about the new processes?
        self.redistribute_queue(queues=queues)

        # After the first partition is done, you need to allocate new operations

        ## TODO: Queue for each process

        ## TODO: Waiting processes after the queue allotment, should use a stack to the other queues to be processed

        # TODO: Keep track of a running total of the approximate time

        # TODO: Final queue is empty? - Return the time

        pass
    
    # Method: Building the partition
    def build_partition(self, queues: List[List[LLMOperation]]) -> list[LLMOperation]:
        
        return queues[0]

    # Method: Get the longest running operation
    def get_longest_op(self, partition: list[LLMOperation]) -> LLMOperation:
        
        # Transforming the partition into a heap

        ## TODO: Convert from min heap to max heap
        heapq.heapify(partition)

        # Taking the largest operation at the beginning
        operation = heapq.heappop(partition)

        return operation

        

    # Method: Reallocation using a stack
    def redistribute_queue(self, queues: List[List[LLMOperation]]) -> List[List[LLMOperation]]:
        pass









