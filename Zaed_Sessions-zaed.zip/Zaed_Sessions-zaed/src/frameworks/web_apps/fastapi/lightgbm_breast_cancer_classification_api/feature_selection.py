import polars as pl

# Custom modules
from utils.feature_util import group_by_query

# URL
url = "https://ashfaq-nsclc-dataset.s3.us-east-1.amazonaws.com/ali_datasets/breast-cancer-dataset.csv"

# Read the CSV as a Polars DataFrame
df = pl.read_csv(source=url)

# Column Name Transformations
df.columns = [col.lower().replace('/', ' ').replace('-', '_').replace('(', '').replace(')', '').replace(' ', '_') for col in df.columns]

# Schema
print(df.schema)

# Describe
print(df.describe())


# SQL Context
with pl.SQLContext(frames={'data': df}) as ctx:
    query = group_by_query(col='metastasis')

    result = ctx.execute(query=query, eager=True)

    print(result)

    # Filter query
    filter_query = """
        SELECT
            age,
            CAST(metastasis AS INT) AS metastasis,
            breast_quadrant,
            CASE
                WHEN diagnosis_result = 'Benign' THEN 0
                ELSE 1
            END AS diagnosis_result
        FROM data
        WHERE metastasis <> '#' AND breast_quadrant <> '#'
    """

    result = ctx.execute(query=filter_query, eager=True)

    print(result)

# One hot encode the breast_quadrant
result_df = result.to_dummies(columns=['breast_quadrant'], separator='_')

print(result_df)

# Rename the columns
unchanged_cols = ['age', 'metastasis']
changed_cols = [col.lower().replace(' ', '_') for col in result_df.columns if 'breast_quadrant' in col]
target_col = ['target']

new_cols = unchanged_cols + changed_cols + target_col

# Updating the columns
result_df.columns = new_cols