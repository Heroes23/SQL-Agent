from os import getcwd, environ
from dotenv import load_dotenv
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL

# Path to the .env file
dotenv_path = getcwd() + "/src/frameworks/data_analytics/snowflake_pandas/.env"

# Load environment variables
load_dotenv(dotenv_path=dotenv_path)

# Build your Snowflake connection URL
url = URL(
    account=environ.get('SNOWFLAKE_ACCOUNT'),
    user=environ.get('SNOWFLAKE_USER'),
    database=environ.get('SNOWFLAKE_DATABASE'),
    schema=environ.get('SNOWFLAKE_SCHEMA'),
    warehouse=environ.get('SNOWFLAKE_WAREHOUSE'),
    role=environ.get('SNOWFLAKE_ROLE'),
    password=environ.get('SNOWFLAKE_PASSWORD'),
    authenticator="USERNAME_PASSWORD_MFA"
)

totp = input("type in your totp: ")

# Engine with SQLAlchemy
engine = create_engine(url=url, connect_args={"passcode": totp})