from fastapi import FastAPI
from uvicorn import run
from typing import Dict, Union

# Custom modules
from validation_models import EmailRegistration, EmailRetrieval

# Build the app object
app = FastAPI()

# Build routes

"""
Routes

### GET Endpoints

1. Test

2. Fetching Random Data


### POST Endpoints

1. get_email
"""

# 1. test route (GET Request)
@app.get(path='/test')
def conduct_test():
    return {'message': 'Test is successfully.'}

# 2. fetch_random_data (GET Request)
@app.get(path='/fetch_data')
def fetch_random_data():
    return {
        'col_one' : list(range(1, 101)),
        'col_two' : list(range(101, 201))
    }

emails = {
    1: 'test@gmail.com',
    2: 'test@pathwise.ai'
}

# 3. register_email
@app.post(path='/register_email')
def register_email(email_registration: EmailRegistration) -> Dict[str, Union[str, int]]:
    
    response = {}
    
    # Retrieve the user_id
    user_id = email_registration.user_id

    # If / else
    if user_id in emails:
        response['user_id'] = user_id
        response['message'] = 'Email has already been registered'
    else:
        # Update the emails dictionary
        emails[user_id] = email_registration.user_email

        response['user_id'] = user_id
        response['email'] = emails[user_id]
        response['message'] = f'Email {emails[user_id]} has been registered successfully.'
    
    return response

    

# Run the web server
run(app=app, host='0.0.0.0', port=8003)