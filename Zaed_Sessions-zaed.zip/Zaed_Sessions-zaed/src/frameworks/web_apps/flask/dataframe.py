import pandas as pd
from os import getcwd

# Path to the CSV file
csv_path = getcwd() + "/data/developer_stress.csv"

# DataFrame
df = pd.read_csv(csv_path)

# Clean the column names
df.columns = [col.lower() for col in df.columns.to_list()]

# Preview the DataFrame
df.info()

# Transform the DataFrame into a list of dictionaries
json_repr = [row[1].to_dict() for row in df.iterrows()]