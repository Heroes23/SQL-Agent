from pydantic import BaseModel, Field

class Joke(BaseModel):
    type: str = Field(description="Does the joke fall under some kind of category?", examples=['dad', 'sport'])
    content: str = Field(description="The actual joke itself.")
    punchline: str = Field(description="What makes the joke funny?")
    comedy_rating: int = Field(le=5, ge=1)
