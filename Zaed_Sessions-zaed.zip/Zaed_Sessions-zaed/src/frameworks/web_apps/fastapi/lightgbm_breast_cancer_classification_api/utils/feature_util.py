

def group_by_query(col: str, table_name: str = 'data') -> str:
    return f"""
        SELECT
            {col},
            COUNT(*) as total_counts
        FROM
            {table_name}
        GROUP BY
            {col}
        ORDER BY
            total_counts DESC
    """