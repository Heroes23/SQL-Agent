import logging
from os import getcwd

# Log Path
log_path = getcwd() + "/data/logs/modular_python_log.txt"

# Basic configuration
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.FileHandler(filename=log_path)]
)

logger = logging.getLogger(name=__file__)