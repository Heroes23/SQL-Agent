from flask import Flask, redirect, jsonify

# Custom modules
from dataframe import json_repr

# Create the app object
app = Flask(__name__)

# Endpoint to say "Hello, data!"
@app.route(rule='/')
def landing():
    return redirect(location='/greeting')

## Decorator
@app.route(rule='/greeting')
def greeting():
    # Return "Hello, data!"
    return "Hello, data!"

@app.route(rule='/data')
def get_data():
    
    return jsonify(json_repr)

# Run the web server
app.run(host='0.0.0.0', port=8002, debug=True)