from langchain_openai import ChatOpenAI

# Custom modules
from joke import Joke

# LLM
llm = ChatOpenAI(model='gpt-5')

# Transform the above LLM into one that supports structured output
llm_structured = llm.with_structured_output(schema=Joke)

# Content
content_input = "Tell me a joke about hydrogen atoms."

# Result
result = llm_structured.invoke(input=content_input)

# To get the result as JSON
print(result.model_dump())